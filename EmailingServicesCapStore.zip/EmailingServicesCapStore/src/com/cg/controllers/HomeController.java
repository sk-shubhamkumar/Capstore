package com.cg.controllers;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Customer;
import com.cg.service.EmailService;

@Controller
public class HomeController {
	EmailService es = new EmailService();

	@RequestMapping("/")
	public String display() {
		return "index";
	}

	@RequestMapping("/signup")
	public String signup(Model model) {
		model.addAttribute("customer", new Customer());
		return "signup";
	}

	@RequestMapping("/validateOTP")
	public String validateOTP(@ModelAttribute("customer") Customer customer) throws IOException {
		es.otpGenerate();
		return "validateOTP";			
	}
	
	@RequestMapping("/submit")
	public String submit(@RequestParam("otp") String otp) throws IOException {
		System.out.println("OTP: "+ otp);
		if(es.validateOTP(otp)) {
			return "success";						
		}
		return "redirect:/validateOTP";
	}
}
