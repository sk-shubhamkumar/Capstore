package com.org.service;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class EmailService {

	public String otpGenerate() throws IOException {
		FileWriter fw;
		String otp = otpCreate();
		File file = new File("D://sts-web-workspace//EmailServ//lib//OTPMailFormat.txt");
		StringBuilder fileContents = new StringBuilder((int) file.length());

		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				fileContents.append(scanner.nextLine() + System.lineSeparator());
			}
			String cont = fileContents.toString();
			String newS = cont.replace("$otp", otp);
			fw = new FileWriter("D://sts-web-workspace//EmailServ//lib//OTPMail.html");
			fw.write(newS);
			fw.close();
		}
		return otp;
	}

	public boolean validateOTP(String inputOTP) throws IOException {
		String location = "D://sts-web-workspace//EmailServ//lib//OTPMail.html";
		FileReader fr = new FileReader(location);
		String fileContents = "";
		String fileOTP = "";
		int i;
		while ((i = fr.read()) != -1) {
			fileContents += (char) i;
		}
		fr.close();
		int index = fileContents.indexOf("Your OTP is");
		fileOTP = fileContents.substring(index + 16, index + 22);
		if (inputOTP.equals(fileOTP)) {
			return true;
		}
		return false;
	}

	public static String otpCreate() {
		Random rndm = new Random();
		int number = rndm.nextInt(999999);
		return String.format("%06d", number);
	}
}
